//
// This file is part of the µOS++ III distribution.
// Copyright (c) 2014 Liviu Ionescu.
//

#ifndef STM32F1_CMSIS_DEVICE_H_
#define STM32F1_CMSIS_DEVICE_H_

#include "stm32f10x.h"

#endif // STM32F1_CMSIS_DEVICE_H_
