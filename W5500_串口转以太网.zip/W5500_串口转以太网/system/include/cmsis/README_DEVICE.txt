The stm32f10x.h and system_stm32f10x.h files are from stsw-stm32054.zip, 
the folder:

	STM32F10x_StdPeriph_Lib_V3.5.0/Libraries/CMSIS/CM3/DeviceSupport/ST/STM32F10x

The cmsis_device.h is added for convenience.

