These files are from stsw-stm32054.zip, the folder:

	STM32F10x_StdPeriph_Lib_V3.5.0/Libraries/STM32F10x_StdPeriph_Driver/src

