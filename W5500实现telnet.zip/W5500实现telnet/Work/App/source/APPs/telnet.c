#include "stm32f10x.h"
#include "types.h"
#include "W5200\w5200.h"
#include "W5200\socket.h"
#include "config.h"
#include "APPs\telnet.h"

#include <stdio.h>
#include <string.h>
#include <ctype.h>

enum tel_cmd {
  HELP_CMD,
  GET_LED_CMD,
  LED3_ON_CMD,
  LED4_ON_CMD,
  LED3_OFF_CMD,
  LED4_OFF_CMD,
  EXIT_CMD  
};

// Command table
char *commands[] = {
  "help",
  "get led",
  "led3 on",
  "led4 on",
  "led3 off",
  "led4 off",
  "exit",
  NULL
};

// Telnet options
char *tel_options[] = {
        "Transmit Binary",
        "Echo",
	"",
	"Suppress Go Ahead",
	"",
	"Status",
	"Timing Mark"
};

//buf in send() : const uint8 * buf
char buf[LINELEN] = {0,};
uint8 remote[NOPTIONS] = {0,};

uint8 telnet_ID[] = {"hello"};
uint8 telnet_PW[] = {"world"};

uint8 user_name[DATA_BUF_SIZE];
uint8 user_password[DATA_BUF_SIZE];
char data_buf[DATA_BUF_SIZE];

uint16 buf_index;

/** 0:close, 1:ready, 2:connected */
extern uint8 ch_status[MAX_SOCK_NUM];

uint8 user_state;

void TELNETS(SOCKET s, uint16 port)
{
  
  switch (getSn_SR(s))	{  
  case SOCK_ESTABLISHED :	
      if(ch_status[s] == ready_state) {  // ready       
        printf("\r\nTdkvdELNET server established via SOCKET %d\r\n", s);
        init_telopt(s);
        ch_status[s] = connected_state;      // connected
      }
            
      if(getSn_RX_RSR(s) > 0) {        
        tel_input(s);          
      }      
      break;
    
   case SOCK_CLOSE_WAIT :      
     printf("\r\nSOCKET %d : CLOSE_WAIT", s);
     disconnect(s);          
     break;
      
   case SOCK_CLOSED :
     if(!ch_status[s]) {
       printf("\r\n----------------------------------- \r\n");
       printf("\r\nW5200 TELNET server start!");
       ch_status[s] = ready_state;           
     } 
     if(socket(s,Sn_MR_TCP,port,0x00) == 0)    /* reinitialize the socket */
     {
       printf("\r\n%d : Fail to create socket.", s);
       ch_status[s] = close_state;
     } else {
       listen(s);
       printf("\r\nSOCKET %d : LISTEN", s);
       user_state = USERNAME;
     }
     break;       
  }
}

void init_telopt(SOCKET s)
{
  sendIAC(s, DO, TN_ENVIRONMENT);
  sendIAC(s, WILL, TN_ECHO);
}

void sendIAC(SOCKET s, uint8 r1, uint8 r2) 
{
  switch(r1) {
  case WILL :
    printf("sent : will");
    break;
    
  case WONT :
    printf("sent : wont");
    break;
    
  case DO :
    printf("sent : do");
    break;
    
  case DONT :
    printf("sent : dont");
    break;  
    
  case IAC :
    break;
  }
  
  if(r2 <= NOPTIONS) {
    printf("%s\r\n", tel_options[r2]);
  } else {
    printf("%u\r\n", r2);
  }
  
  sprintf(buf, "%c%c%c", IAC, r1, r2);  
  send(s, (uint8 const *)buf, 3, FALSE);
    
}

void tel_input(SOCKET s)
{
  uint8 c;
  uint8 input_command[] ="W5200>";
  while(1)
  {
    if(getSn_RX_RSR(s) == 0 ) break;
    if(recv(s, &c, 1) == 0) break;
    if(user_state == LOGOUT) break;   
    
    if(c != IAC) {
      data_buf[buf_index++] = c;
      putchar(c);
      
      if(user_state != PASSWORD) {  
        sprintf(buf, "%c", c);
        send(s, (uint8 const *)buf, strlen(buf), FALSE);
      }
      
      if(c == '\n') {
        if(buf_index > 1) {
                    
          if(data_buf[buf_index-2] == '\r') {
            data_buf[buf_index-2] = '\0';
          } else {
            data_buf[buf_index-1] = '\0';
          }
          
          if(user_state != LOGIN) login(s);
          else proc_command(s);
          
          if(user_state == LOGIN) {           
            send(s, input_command, 6, FALSE);
          }
        } else {         
          send(s, input_command, 6, FALSE); 
        }
        buf_index = 0;
      }
      continue; 
    }    
      
    if(recv(s, &c, 1) == 0) break;     
    switch(c) {
    case WILL :
      if(recv(s, &c, 1) == 0) break;
      willopt(s, c);
      break;
    case WONT :
      if(recv(s, &c, 1) == 0) break;
      wontopt(s, c);
      break;
    case DO :
      if(recv(s, &c, 1) == 0) break;
      doopt(s, c);
      break;
    case DONT :
      if(recv(s, &c, 1) == 0) break;
      dontopt(c);
      break;
    case IAC :
      break;      
    }
    break;
  }
}

void willopt(SOCKET s, uint16 opt)
{
  int ack;
  printf("recv: will");
  if(opt <= NOPTIONS) {
    printf("%s\r\n", tel_options[opt]);
  } else {
    printf("%u\r\n", opt);
  }
  
  switch(opt) {
  case TN_TRANSMIT_BINARY :
  case TN_ECHO :
  case TN_SUPPRESS_GA :
    ack = DO;
    break;
  default :
    ack = DONT;
  }
  sendIAC(s, ack, opt);
}

void wontopt(SOCKET s, uint16 opt)
{
  printf("recv: wont");
  if(opt <= NOPTIONS) {
    printf("%s\r\n", tel_options[opt]);
  } else {
    printf("%u\r\n", opt);
  }
  
  switch(opt) {
  case TN_TRANSMIT_BINARY :
  case TN_ECHO :
  case TN_SUPPRESS_GA :
    if(remote[opt] == 0) {
      remote[opt] = 1;
      sendIAC(s, DONT, opt);
    }
    break;
  }
}

void doopt(SOCKET s, uint16 opt)
{
  printf("recv: do ");
  if(opt <= NOPTIONS) {
    printf("%s\r\n", tel_options[opt]);
  } else {
    printf("%u\r\n", opt);
  }
  
  switch(opt) {
  case TN_SUPPRESS_GA :
    sendIAC(s, WILL, opt);
    break;
  case TN_ECHO :
    sprintf(buf, "WELCOME!\r\nID : ");
    send(s, (uint8 const *)buf, strlen(buf), FALSE);
    break;
  default :
    sendIAC(s, WONT, opt);
  }  
}

void dontopt(uint16 opt)
{
  printf("recv: dont ");
  if(opt <= NOPTIONS) {
    printf("%s\r\n", tel_options[opt]);
  } else {
    printf("%u\r\n", opt);
  }
  
  switch(opt) {
  case TN_TRANSMIT_BINARY :
  case TN_ECHO :
  case TN_SUPPRESS_GA :
    if(remote[opt] == 0) {
      remote[opt] = 1;     
    }
    break;
  }  
}
  
void proc_command(SOCKET s)
{  
  char **cmdp;
  //char *cp;
  char *help = {"HELP: Show all available commands\
    \r\nGET LED: Show all LED status\
    \r\nLED3 ON/OFF: Turn ON/OFF the LED3\
    \r\nLED4 ON/OFF: Turn ON/OFF the LED4\
    \r\nEXIT: Exit from W5200 TELNET server\r\n"}; 
  
  /*
  for(cp = data_buf; *cp != '\0';  cp++){
    *cp = tolower(*cp);       
  }
  */
    
  if(*data_buf != '\0') {
    
    for(cmdp = commands; *cmdp != NULL; cmdp++) {      
      if(strncmp(*cmdp, data_buf, strlen(*cmdp)) == 0) break;      
    }
    
    if(*cmdp == NULL) {
      printf("NULL command\r\n");
      sprintf(buf, "%s : BAD command\r\n", data_buf);
      send(s, (uint8 const *)buf, strlen(buf), FALSE);
      return;
    }
    
    switch(cmdp - commands) {
         
    case HELP_CMD :
      printf("HELP_CMD\r\n");
      sprintf(buf, help);
      send(s, (uint8 const *)buf, strlen(buf), FALSE);
      break;
    
    case GET_LED_CMD :
      printf("GET_LED_CMD\r\n");      
      sprintf(buf, "LED%d is %s\r\n", 3, GPIO_ReadOutputDataBit(GPIOA, LED3) ? "OFF" : "ON");
      send(s, (uint8 const *)buf, strlen(buf), FALSE);
      sprintf(buf, "LED%d is %s\r\n", 4, GPIO_ReadOutputDataBit(GPIOA, LED4) ? "OFF" : "ON");
      send(s, (uint8 const *)buf, strlen(buf), FALSE);
      break;
      
    case LED3_ON_CMD :
      printf("LED3_ON_CMD\r\n");
      sprintf(buf, "Turn ON the LED3\r\n");
      send(s, (uint8 const *)buf, strlen(buf), FALSE);
      GPIO_ResetBits(GPIOA, LED3); // led3 on
      break;
      
    case LED4_ON_CMD :
      printf("LED4_ON_CMD\r\n");
      sprintf(buf, "Turn ON the LED4\r\n");
      send(s, (uint8 const *)buf, strlen(buf), FALSE);
      GPIO_ResetBits(GPIOA, LED4); // led4 on
      break;
      
    case LED3_OFF_CMD :
      printf("LED3_OFF_CMD\r\n");
      sprintf(buf, "Turn OFF the LED3\r\n");
      send(s, (uint8 const *)buf, strlen(buf), FALSE);
      GPIO_SetBits(GPIOA, LED3); // led3 off      
      break;
    
    case LED4_OFF_CMD :
      printf("LED4_OFF_CMD\r\n");
      sprintf(buf, "Turn OFF the LED4\r\n");
      send(s, (uint8 const *)buf, strlen(buf), FALSE);
      GPIO_SetBits(GPIOA, LED4); // led4 off      
      break;
      
    case EXIT_CMD :
      printf("EXIT command\r\n");
      sprintf(buf, "EXIT command\r\nGood bye!\r\nLogout from W5200 TELNET\r\n");
      send(s, (uint8 const *)buf, strlen(buf), FALSE);
      close(s); 
      user_state = LOGOUT;
      break;
    
    default :
      break;
    }
  }
}

void login(SOCKET s)
{  
  if(user_state == USERNAME) {            // login process
    strcpy((char *)user_name, data_buf);    
    sprintf(buf, "Password : ");
    send(s, (uint8 const *)buf, strlen(buf), FALSE);
    user_state = PASSWORD;
    return;
  } else if(user_state == PASSWORD) {
    strcpy((char *)user_password, data_buf);   
    
    /*Check the client name and password*/    
    if(!(strcmp((char const *)user_name, (char const *)telnet_ID)) && !(strcmp((char const *)user_password, (char const *)telnet_PW))) {
      sprintf(buf, "\r\n=======================");
      send(s, (uint8 const *)buf, strlen(buf), FALSE);
      sprintf(buf, "\r\nSuccessfully connected!\
        \r\nImplemented Commands : HELP, GET LED, LED3 ON/OFF, LED4 ON/OFF, EXIT\r\n");                      
      send(s, (uint8 const *)buf, strlen(buf), FALSE);
      sprintf(buf, "=======================\r\n");
      send(s, (uint8 const *)buf, strlen(buf), FALSE);
      user_state = LOGIN;
      return;
    } else {
      sprintf(buf, "\r\nID or Password incorrect!\r\n");
      send(s, (uint8 const *)buf, strlen(buf), FALSE);
      sprintf(buf, "ID : ");
      send(s, (uint8 const *)buf, strlen(buf), FALSE);
      user_state = USERNAME;
      return;      
    }
  }
}