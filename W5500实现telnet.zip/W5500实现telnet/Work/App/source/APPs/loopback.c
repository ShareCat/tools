#include "stm32f10x.h"
#include "config.h"
#include "W5200\w5200.h"
#include "W5200\socket.h"
#include "util.h"
#include "APPs\loopback.h"
#include <stdio.h>

#define tick_second 1

extern uint8 I_STATUS[MAX_SOCK_NUM];
extern void EXTI_IMR_EMR_disable(void);
extern void EXTI_IMR_EMR_enable(void);

extern uint8 ch_status[MAX_SOCK_NUM];
extern CHCONFIG_TYPE_DEF Chconfig_Type_Def; 
uint16 any_port = 1000;
uint8 tmp_I_STATUS = 0;

#ifndef __DEF_IINCHIP_INT__
void loopback_tcps(SOCKET s, uint16 port)
{	
	uint16 len;  
	uint8 * data_buf = (uint8*) TX_BUF;
	uint16 send_data_len = 0;
	uint8 tmp_retry_cnt =0;        
	
//	uint8 tmp_I_STATUS_FLAG = 0;
//#ifdef __DEF_IINCHIP_INT__

 	//printf(".");
	//EXTI_IMR_EMR_disable();           
	//printf("/");                       
	tmp_I_STATUS = I_STATUS[s];
	I_STATUS[s] &= ~(tmp_I_STATUS); //Clear
	if(tmp_I_STATUS)
		{
			printf("tmpisr = %.2X \r\n",tmp_I_STATUS);
		}
	//EXTI_IMR_EMR_enable();
	//#endif
        
	switch (getSn_SR(s))
	{
		case SOCK_ESTABLISHED:					/* if connection is established */
			if(ch_status[s]==1)
			{
				printf("\r\n%d : Connected(Polling Mode)",s);
				printf("\r\n Peer IP : %d.%d.%d.%d", IINCHIP_READ(Sn_DIPR0(s)+0),  IINCHIP_READ(Sn_DIPR0(s)+1), IINCHIP_READ(Sn_DIPR0(s)+2), IINCHIP_READ(Sn_DIPR0(s)+3));
				printf("\r\n Peer Port : %d", ( (uint16)(IINCHIP_READ(Sn_DPORT0(s)+0)<<8) +(uint16)IINCHIP_READ(Sn_DPORT0(s)+1)));
				ch_status[s] = 2;
			}
#if 0		
//#ifdef __DEF_IINCHIP_INT__
			
			if ( (tmp_I_STATUS  & Sn_IR_RECV))
			{
//#endif			
				while (!(len = getSn_RX_RSR(s))); 			/* check Rx data */
				//if ((len = getSn_RX_RSR(s)) > 0) 			/* check Rx data */
				{
					if (len > TX_RX_MAX_BUF_SIZE) len = TX_RX_MAX_BUF_SIZE;	/* if Rx data size is lager than TX_RX_MAX_BUF_SIZE */
					//printf("recv_data_len : %d \r\n",len);
					/* the data size to read is MAX_BUF_SIZE. */
					len = recv(s, data_buf, len); //recv len			/* read the received data */
                               printf("recv_data_len : %d \r\n",len);
                        	wait_4us(5);wait_4us(5);wait_4us(5);
                        	//wait_4us(5);wait_4us(5);wait_4us(5);
					send_data_len = send(s, data_buf, len, (bool)WINDOWFULL_FLAG_OFF);	/* sent the received data */
					if(send_data_len!=len) // ohly assert when windowfull
					{
						init_windowfull_retry_cnt(s);			
						while(send_data_len !=  len) 
						{
							printf("ret :%d\r\n", send_data_len);
							tmp_retry_cnt = incr_windowfull_retry_cnt(s);
							
							if(tmp_retry_cnt <= WINDOWFULL_MAX_RETRY_NUM) 
							{
								send_data_len += send(s, data_buf, len, (bool)WINDOWFULL_FLAG_ON); 
								wait_1ms(WINDOWFULL_WAIT_TIME);
							} 
							else 
							{
								printf("WindowFull !!!\r\n");
								close(s);
								printf("Socket Close !!!\r\n");
								while(1);
							}
						}			
					}
	                    printf("send_data_len : %d \r\n",send_data_len);
				}
//#ifdef __DEF_IINCHIP_INT__									
 				//tmp_I_STATUS &= ~(Sn_IR_RECV); //Clear RECV 
			}                             
//#endif									
#endif
		break;
		
		case SOCK_CLOSE_WAIT:                           	/* If the client request to close */
			printf("\r\n%d : CLOSE_WAIT", s);
			if ((len = getSn_RX_RSR(s)) > 0) 		/* check Rx data */
			{
				if (len > TX_RX_MAX_BUF_SIZE) len = TX_RX_MAX_BUF_SIZE;	/* if Rx data size is lager than TX_RX_MAX_BUF_SIZE */
																/* the data size to read is MAX_BUF_SIZE. */
				len = recv(s, data_buf, len);		/* read the received data */
			}
			disconnect(s);
			ch_status[s] = 0;
		break;
		case SOCK_CLOSED:                                       /* if a socket is closed */
			if(!ch_status[s]) 
			{
				printf("\r\n%d : Loop-Back TCP Server Started. port : %d", s, port);
				ch_status[s] = 1;
			}
			if(socket(s,Sn_MR_TCP,port,0x00) == 0)    /* reinitialize the socket */
			{
				printf("\r\n%d : Fail to create socket.",s);
				ch_status[s] = 0;
			}
			else	listen(s);
		break;
	}
}
#else
void loopback_tcps(SOCKET s, uint16 port)
{	
        uint16 len, cnt=0;
        uint8 * data_buf = (uint8*) TX_BUF;
        uint16 send_data_len = 0;
        uint8 tmp_retry_cnt =0;
        uint8 tmp = 0;

	uint16 ptr, SEND_SIZE=128;

        //printf("I_STATUS[s] :%X\r\n",I_STATUS[s]);
	switch(I_STATUS[s]){
		case 0x00: 
			// cloes
			if(!ch_status[s]) 
			{
				printf("\r\n%d : Loop-Back TCP Server Started. port : %d", s, port);
				ch_status[s] = 1;

				if(socket(s,Sn_MR_TCP,port,0x00) == 0)    /* reinitialize the socket */
				{
					printf("\r\n%d : Fail to create socket.",s);
					ch_status[s] = 0;
				}
				else	{
					printf("\r\n%d : Create socket.",s);
					listen(s);
				}
			}
			break;
		case 0x01: 
			// connected
			printf("\r\n%d : Connected(Interrept Mode)",s);
                        printf("\r\n Peer IP : %d.%d.%d.%d", IINCHIP_READ(Sn_DIPR0(s)+0),  IINCHIP_READ(Sn_DIPR0(s)+1), IINCHIP_READ(Sn_DIPR0(s)+2), IINCHIP_READ(Sn_DIPR0(s)+3));
                        printf("\r\n Peer Port : %d", ( (uint16)(IINCHIP_READ(Sn_DPORT0(s)+0)<<8) +(uint16)IINCHIP_READ(Sn_DPORT0(s)+1)));
			ch_status[s] = 2;
			
			I_STATUS[s] &= ~(0x01);

#if 0	//TCP_SEND_ONLY
			while(1){
				if(cnt++ > 1) while(1);

				ptr = IINCHIP_READ(Sn_TX_WR0(s));
                                ptr = (ptr << 8) + IINCHIP_READ(Sn_TX_WR0(s) + 1);

				IINCHIP_WRITE(Sn_CR(s),Sn_CR_SEND);
                                while( IINCHIP_READ(Sn_CR(s)) );

				ptr += SEND_SIZE;

				IINCHIP_WRITE(Sn_TX_WR0(s),(uint8)((ptr & 0xff00) >> 8));
				IINCHIP_WRITE((Sn_TX_WR0(s) + 1),(uint8)(ptr & 0x00ff));
			}
#else
			break;
#endif
		case 0x02: 
			// discon
			printf("\r\n%d : CLOSE_WAIT", s);
	                if ((len = getSn_RX_RSR(s)) > 0) 		/* check Rx data */
			{
				if (len > TX_RX_MAX_BUF_SIZE) len = TX_RX_MAX_BUF_SIZE;	/* if Rx data size is lager than TX_RX_MAX_BUF_SIZE */
				len = recv(s, data_buf, len);		/* read the received data */
			}
			disconnect(s);
			ch_status[s] = 0;
			
			I_STATUS[s] &= ~(0x02);
			
			break;
		case 0x04: 
                        IINCHIP_WRITE(IMR, 0x00);
                        IINCHIP_WRITE(IMR2, 0x00);
                        EXTI_IMR_EMR_disable();

                        tmp = I_STATUS[s];
                  	I_STATUS[s] &= ~(0x04); // RECV

                        EXTI_IMR_EMR_enable();
                        IINCHIP_WRITE(IMR, 0xF0);
                        IINCHIP_WRITE(IMR2, 0xFF);

#if 0	// TCP_RECEIVE_ONLY
			if(getSn_RX_RSR(s) > ((16*1024)-(1460*3))){
				ptr = IINCHIP_READ(Sn_RX_RD0(s));
				ptr = ((ptr & 0x00ff) << 8) + IINCHIP_READ(Sn_RX_RD0(s) + 1);

				ptr += getSn_RX_RSR(s);
				//ptr &= getIINCHIP_RxMASK(s);

				IINCHIP_WRITE(Sn_RX_RD0(s),(uint8)((ptr & 0xff00) >> 8));
				IINCHIP_WRITE((Sn_RX_RD0(s) + 1),(uint8)(ptr & 0x00ff));

				IINCHIP_WRITE(Sn_CR(s),Sn_CR_RECV);
				while( IINCHIP_READ(Sn_CR(s)));
			}
			break;
#endif
			// recv
                        if (tmp & 0x04)
                        {
                          if ((len = getSn_RX_RSR(s)) > 0) 		/* check Rx data */
                          {
                                  if (len > TX_RX_MAX_BUF_SIZE) len = TX_RX_MAX_BUF_SIZE;	/* if Rx data size is lager than TX_RX_MAX_BUF_SIZE */

                                  len = recv(s, data_buf, len);	/* read the received data */
                                  //printf("recv_data_len : %d, getSn_RX_RSR(%d) : %d\r\n", len, s, getSn_RX_RSR(s));

#if 1 // loopback..
                                  send_data_len = send(s, data_buf, len, (bool)WINDOWFULL_FLAG_OFF);	/* sent the received data */
                                  //printf("send_data_len : %d /r/n",send_data_len);
                                     if(send_data_len!=len) // ohly assert when windowfull
                                      {
                                          init_windowfull_retry_cnt(s);
                                          while(send_data_len !=  len)
                                          {
                                                  printf("ret :%d\r\n", send_data_len);
                                                  tmp_retry_cnt = incr_windowfull_retry_cnt(s);
                                                  
                                                  if(tmp_retry_cnt <= WINDOWFULL_MAX_RETRY_NUM)
                                                  {
                                                                  send_data_len += send(s, data_buf, len, (bool)WINDOWFULL_FLAG_ON);
                                                                  wait_1ms(WINDOWFULL_WAIT_TIME);
                                                  }
                                                  else
                                                  {
                                                                  printf("WindowFull !!!\r\n");
                                                                  close(s);
                                                                  printf("Socket Close !!!\r\n");
                                                                  while(1);
                                                  }
                                          }
                                       }
#endif
                          }
                        }

			//I_STATUS[s] &= ~(0x10); // send ok
			break;
		case 0x10: 
			// send ok
			
			//I_STATUS[s] &= ~(0x10);
			break;
	}

#if (__MCU_TYPE__ == __MCU_STM32F103__)
        /**/
        if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0x00) EXTI_GenerateSWInterrupt(EXTI_Line0);
#endif
}
#endif
void loopback_tcpc(SOCKET s, uint16 port)
{
	uint16 len;							
	uint8 * data_buf = (u8*) TX_BUF;
        uint16 send_data_len = 0;
        uint8 tmp_retry_cnt =0;
        
	switch (getSn_SR(s))
	{
	case SOCK_ESTABLISHED:						/* if connection is established */
		if(ch_status[s]==1)
		{
			printf("\r\n%d : Connected",s);			
			ch_status[s] = 2;
		}
		if ((len = getSn_RX_RSR(s)) > 0) 			/* check Rx data */
		{
			if (len > TX_RX_MAX_BUF_SIZE) len = TX_RX_MAX_BUF_SIZE;	/* if Rx data size is lager than TX_RX_MAX_BUF_SIZE */
									/* the data size to read is MAX_BUF_SIZE. */
			len = recv(s, data_buf, len); //recv len			/* read the received data */
                printf("recv_data_len : %d\r\n", len);
                

            	send_data_len = send(s, data_buf, len, (bool)WINDOWFULL_FLAG_OFF);	/* sent the received data */
                printf("send_data_len : %d\r\n", send_data_len);
                if(send_data_len!=len) // ohly assert when windowfull
                {
                    init_windowfull_retry_cnt(s);			
                    while(send_data_len !=  len) 
                    {
                            printf("ret :%d\r\n", send_data_len);
                            tmp_retry_cnt = incr_windowfull_retry_cnt(s);
                            
                            if(tmp_retry_cnt <= WINDOWFULL_MAX_RETRY_NUM) 
                            {
                                            send_data_len += send(s, data_buf, len, (bool)WINDOWFULL_FLAG_ON); 
                                            wait_1ms(WINDOWFULL_WAIT_TIME);
                            } 
                            else 
                            {
                                            printf("WindowFull !!!\r\n");
                                            close(s);
                                            printf("Socket Close !!!\r\n");
                                            while(1);
                            }
                    }			
                 }
		}
		break;
	case SOCK_CLOSE_WAIT:                           		/* If the client request to close */
		printf("\r\n%d : CLOSE_WAIT", s);
		if ((len = getSn_RX_RSR(s)) > 0) 			/* check Rx data */
		{
			if (len > TX_RX_MAX_BUF_SIZE) len = TX_RX_MAX_BUF_SIZE;	/* if Rx data size is lager than TX_RX_MAX_BUF_SIZE */
																												/* the data size to read is MAX_BUF_SIZE. */
			len = recv(s, data_buf, len);			/* read the received data */
		}
		disconnect(s);
		ch_status[s] = 0;
		break;
	case SOCK_CLOSED:                                               /* if a socket is closed */
		if(!ch_status[s])
		{
			printf("\r\n%d : Loop-Back TCP Client Started. port: %d", s, port);
			ch_status[s] = 1;
		}
		//if(socket(s, Sn_MR_TCP, any_port++, 0x00) == 0)    /* reinitialize the socket */
		if(socket(s, Sn_MR_TCP, port, 0x00) == 0)    /* reinitialize the socket */
		{
			printf("\a%d : Fail to create socket.",s);
			ch_status[s] = 0;
		}
		else	connect(s, Chconfig_Type_Def.destip, Chconfig_Type_Def.port);
		break;
	}
}

void loopback_udp(SOCKET s, uint16 port)
{
	uint16 len;
	uint8 * data_buf = (u8*) TX_BUF;
	uint32 destip = 0;
	uint16 destport;
        uint8 addr[4] = {192, 168, 11, 237};

	uint16 ptr, SEND_SIZE=128;

	switch (getSn_SR(s))
	{
	case SOCK_UDP:
#if 1	//UDP_SEND_ONLY
		while(1){
			IINCHIP_WRITE(Sn_DIPR0(s),addr[0]);
			IINCHIP_WRITE((Sn_DIPR0(s) + 1),addr[1]);
			IINCHIP_WRITE((Sn_DIPR0(s) + 2),addr[2]);
			IINCHIP_WRITE((Sn_DIPR0(s) + 3),addr[3]);
			IINCHIP_WRITE(Sn_DPORT0(s),(uint8)((port & 0xff00) >> 8));
			IINCHIP_WRITE((Sn_DPORT0(s) + 1),(uint8)(port & 0x00ff));

			ptr = IINCHIP_READ(Sn_TX_WR0(s));
			ptr = (ptr << 8) + IINCHIP_READ(Sn_TX_WR0(s) + 1);

			IINCHIP_WRITE(Sn_CR(s),Sn_CR_SEND);
			while( IINCHIP_READ(Sn_CR(s)) );

			ptr += SEND_SIZE;

			IINCHIP_WRITE(Sn_TX_WR0(s),(uint8)((ptr & 0xff00) >> 8));
			IINCHIP_WRITE((Sn_TX_WR0(s) + 1),(uint8)(ptr & 0x00ff));
		}
#else
		if ((len = getSn_RX_RSR(s)) > 0) 			/* check Rx data */
		{
			if (len > TX_RX_MAX_BUF_SIZE) len = TX_RX_MAX_BUF_SIZE;	/* if Rx data size is lager than TX_RX_MAX_BUF_SIZE */
										/* the data size to read is MAX_BUF_SIZE. */
			len = recvfrom(s, data_buf, len,(uint8*)&destip,&destport);	/* read the received data */
			if(sendto(s, data_buf, len,(uint8*)&destip,destport) == 0)	/* send the received data */
			{
				printf("\a\a\a%d : System Fatal Error.", s);
			}
		}


		IINCHIP_WRITE(Sn_DIPR0(s),addr[0]);
		IINCHIP_WRITE((Sn_DIPR0(s) + 1),addr[1]);
		IINCHIP_WRITE((Sn_DIPR0(s) + 2),addr[2]);
		IINCHIP_WRITE((Sn_DIPR0(s) + 3),addr[3]);
		IINCHIP_WRITE(Sn_DPORT0(s),(uint8)((port & 0xff00) >> 8));
		IINCHIP_WRITE((Sn_DPORT0(s) + 1),(uint8)(port & 0x00ff));
#endif

	case SOCK_CLOSED:                                               /* if a socket is closed */
		printf("\r\n%d : Loop-Back UDP Started. port :%d", s, port);
		if(socket(s,Sn_MR_UDP,port,0x00)== 0)    /* reinitialize the socket */
			printf("\a%d : Fail to create socket.",s);

		break;
	}
}

